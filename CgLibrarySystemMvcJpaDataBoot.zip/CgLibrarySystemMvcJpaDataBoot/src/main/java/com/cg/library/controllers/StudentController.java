package com.cg.library.controllers;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.library.beans.Student;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.services.LibraryServices;

@Controller
public class StudentController {
	LibraryServices libraryServices;
@RequestMapping("/registerationSuccessful")
public ModelAndView getRegistration(@Valid@ModelAttribute Student student,BindingResult bindingresult) throws LibraryServicesDownException {
	if(bindingresult.hasErrors())
		return new ModelAndView("registerPage");
	int studentID=libraryServices.registerStudent(student);
	return new ModelAndView("registrationSuccessPage","studentID",studentID);
}
}
