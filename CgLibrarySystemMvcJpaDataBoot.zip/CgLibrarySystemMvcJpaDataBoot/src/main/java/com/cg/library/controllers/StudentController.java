package com.cg.library.controllers;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.StudentNotFoundException;
import com.cg.library.services.LibraryServices;
@Controller
public class StudentController {
	@Autowired
	LibraryServices libraryServices;
	Book book;
	@RequestMapping("/registrationSuccessful")
	public ModelAndView getRegistration(@Valid@ModelAttribute Student student,BindingResult bindingresult) throws LibraryServicesDownException {
		if(bindingresult.hasErrors())
			return new ModelAndView("registerPage");
		student=libraryServices.registerStudent(student);
		return new ModelAndView("registrationSuccessPage","student",student);
	}
	@RequestMapping("/getLoginPage")
	public ModelAndView getLoginPage(@RequestParam("studentID")int studentID) throws LibraryServicesDownException {
		try {
			libraryServices.loginStudent(studentID);
		} catch (StudentNotFoundException e) {
			return new ModelAndView("loginPage","errorMesssage","Student ID not found!!Please try again");
		}
		return new ModelAndView("libraryIndexPage");
	}
	
	@RequestMapping("/viewAllBook")
	public ModelAndView getAllBooks(){
		List<Book> bookList=libraryServices.viewAllBook();
		return new ModelAndView("viewAllBookPage","bookList",bookList);
	}
	@RequestMapping("/getBookIssue")
	public ModelAndView getBookIssue(@RequestParam("bookID")int bookID) throws BookNotFoundException {
		try {
			Book book=libraryServices.issueBook(bookID);
			return new ModelAndView("bookIssueSuccessful","book",book);
		} catch (BookNotFoundException e) {
			return new ModelAndView("getbookIssuePage","errorMesssage","Book ID not found!!Please try again");
		}
	}
}
