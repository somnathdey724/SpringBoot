package com.cg.library.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.library.beans.Student;

@Controller
public class URIController {
	Student student;
	@RequestMapping("/")
	public String getIndexPage() {
		return "registerPage";
	}
	@ModelAttribute
	public Student getStudent() {
		student= new Student();
		return student;
	}
}
