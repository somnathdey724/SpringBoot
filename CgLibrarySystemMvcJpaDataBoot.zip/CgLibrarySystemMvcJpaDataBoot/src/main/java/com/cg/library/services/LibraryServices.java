package com.cg.library.services;

import java.util.Date;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.StudentNotFoundException;

public interface LibraryServices {
	public int registerStudent(Student student) throws LibraryServicesDownException;
	public int issueBook(Book bookID) throws BookNotFoundException;
	public int returnBook(Book bookID);
	public int calculateFine(int studentID,int bookID) throws StudentNotFoundException,BookNotFoundException;
	public Book viewAllBookDetails();
	public Book viewStudentBookDetails(Student studentID)throws StudentNotFoundException;
}
