package com.cg.library.services;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.StudentDAO;
import com.cg.library.exception.BookAlreadyPresentException;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.RegistrationDateNotFound;
import com.cg.library.exception.StudentNotFoundException;
@Component("libraryServices")
public class LibraryServicesImpl implements LibraryServices{
	@Autowired
	private BookDAO bookDAO;
	@Autowired
	private StudentDAO studentDAO;
	Student student;
	Book book;
	@Override
	public Student registerStudent(Student student) throws LibraryServicesDownException {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.now();
		//System.out.println(dtf.format(localDate));
		//Date date = new Date();
		student.setregisterDate(dtf.format(localDate));
		student=studentDAO.save(student);

		return student;
	}

	@Override
	public Book issueBook(int bookID) throws BookNotFoundException {
		book = bookDAO.findById(bookID).orElseThrow(()->new BookNotFoundException("Book not found"));
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.now();
		book.setIssueDate(dtf.format(localDate));
		LocalDate returnDate = localDate.plusDays(30);
		book.setReturnDate(returnDate);
		//bookDAO.delete(book);
		bookDAO.changeStatus(bookID, "Issued");
		return book;
	}

	@Override
	public long returnBook(int bookID) throws BookAlreadyPresentException, BookNotFoundException {
		if(bookDAO.findById(bookID).get()==null) {
			/*int virtualBookID=bookID;
			virtualBookDAO.findById(virtualBookID).orElseThrow(()-> new BookNotFoundException("No match in database"));	
			*/
			LocalDate issueDate = LocalDate.parse(book.getIssueDate());
			LocalDate returnDate = LocalDate.now();
			long noOfDaysBetween = ChronoUnit.DAYS.between(issueDate, returnDate);
			if(noOfDaysBetween>30) {
				return 0;}
			else {
				return noOfDaysBetween*5;
		}}
		else {
			throw new BookAlreadyPresentException("Book already present");
		}
	}
	@Override
	public int calculateFine(int studentID, int bookID) throws StudentNotFoundException, BookNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}
	static int counter=0;
	@Override
	public List<Book> viewAllBook() {
		if(counter<1) {
			Book book = new Book("An Autobiography", "Jawaharlal Nehru","Available");
			bookDAO.save(book);
			book = new Book("An idealist View of Life", "Dr.S. Radhakrishnan","Available");
			bookDAO.save(book);
			book = new Book("Life of Pi", "Yann Martel","Available");
			bookDAO.save(book);
			book = new Book("Yama ", "Mahadevi Verma","Available");
			bookDAO.save(book);
			book = new Book("Kitne Pakistan", "Kamleshwar","Available");
			bookDAO.save(book);
			counter++;
		}
		List<Book> bookList=bookDAO.findAll();
		return bookList;
	}


	@Override
	public Book viewStudentBookDetails(Student studentID) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loginStudent(int studentID,String registerDate) throws LibraryServicesDownException, StudentNotFoundException, RegistrationDateNotFound {
		student=studentDAO.findById(studentID).orElseThrow(()->new StudentNotFoundException("Student not found"));
		if(registerDate.compareTo(student.getregisterDate())==0) {	
		}		
		else
			throw new RegistrationDateNotFound("Date mismatch");
	}

	@Override
	public List<Book> addBook(String bookName, String bookAuthor) {
		book= new Book(bookName, bookAuthor);
		bookDAO.save(book);
		List<Book> books=bookDAO.findAll();
		return books;
	}

	@Override
	public void removeBook(int bookID) throws BookNotFoundException {
		book = bookDAO.findById(bookID).orElseThrow(()->new BookNotFoundException("Book not found"));
		bookDAO.delete(book);
	}

	@Override
	public void updateBook(int bookID, String bookName) throws BookNotFoundException {
		book = bookDAO.findById(bookID).orElseThrow(()->new BookNotFoundException("Book not found"));
		bookDAO.Updatebook(bookID, bookName);
	}

}
