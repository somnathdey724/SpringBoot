package com.cg.library.services;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.StudentDAO;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.StudentNotFoundException;

import oracle.net.aso.b;
@Component("libraryServices")
public class LibraryServicesImpl implements LibraryServices{
	@Autowired
	private BookDAO bookDAO;
	@Autowired
	private StudentDAO studentDAO;
	Student student;
	Book book;
	@Override
	public Student registerStudent(Student student) throws LibraryServicesDownException {
		student=studentDAO.save(student);
		return student;
	}

	@Override
	public Book issueBook(int bookID) throws BookNotFoundException {
		book = bookDAO.findById(bookID).orElseThrow(()->new BookNotFoundException("Book not found"));
		Date date= new Date();
		book.setIssueDate(date.toString());
		  Calendar c = Calendar.getInstance();
		book.setReturnDate(c.add(Calendar.MONTH, 1));
		bookDAO.delete(book);
		return book;
	}

	@Override
	public int returnBook(Book bookID) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int calculateFine(int studentID, int bookID) throws StudentNotFoundException, BookNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}
	static int counter=0;
	@Override
	public List<Book> viewAllBook() {
		if(counter<1) {
		Book book = new Book("An Autobiography", "Jawaharlal Nehru");
		bookDAO.save(book);
		book = new Book("An idealist View of Life", "Dr.S. Radhakrishnan");
		bookDAO.save(book);
		book = new Book("Life of Pi", "Yann Martel");
		bookDAO.save(book);
		book = new Book("Yama ", "Mahadevi Verma");
		bookDAO.save(book);
		book = new Book("Kitne Pakistan", "Kamleshwar");
		bookDAO.save(book);
		counter++;
	}
		List<Book> bookList=bookDAO.findAll();
		return bookList;
	}
		

	@Override
	public Book viewStudentBookDetails(Student studentID) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loginStudent(int studentID) throws LibraryServicesDownException, StudentNotFoundException {
		student=studentDAO.findById(studentID).orElseThrow(()->new StudentNotFoundException("Student not found"));
		
	}

}
