package com.cg.library.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.StudentDAO;
import com.cg.library.exception.BookNotFoundException;
import com.cg.library.exception.LibraryServicesDownException;
import com.cg.library.exception.StudentNotFoundException;
@Component("libraryServices")
public class LibraryServicesImpl implements LibraryServices{
	@Autowired
	private BookDAO bookDAO;
	@Autowired
	private StudentDAO studentDAO;
	@Override
	public int registerStudent(Student student) throws LibraryServicesDownException {
		student=studentDAO.save(student);
		return student.getStudentID();
	}

	@Override
	public int issueBook(Book bookID) throws BookNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int returnBook(Book bookID) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int calculateFine(int studentID, int bookID) throws StudentNotFoundException, BookNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Book viewAllBookDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book viewStudentBookDetails(Student studentID) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
