package com.cg.library.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.library.beans.Book;

public interface BookDAO extends JpaRepository<Book, Integer> {
	@Modifying
	@Transactional
	@Query(value="UPDATE Book SET BOOK_NAME=?2 WHERE BOOKID=?1", nativeQuery=true)
	void Updatebook(int bookID,String bookName);
	@Modifying
	@Transactional
	@Query(value="UPDATE Book SET STATUS=?2 WHERE BOOKID=?1", nativeQuery=true)
	void changeStatus(int bookID,String status);
}
